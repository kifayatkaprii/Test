package com.facebook.ads;

public final class R {
}
