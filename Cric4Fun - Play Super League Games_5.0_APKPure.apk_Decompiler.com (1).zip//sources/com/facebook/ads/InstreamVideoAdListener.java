package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public interface InstreamVideoAdListener extends AdListener {
    void onAdVideoComplete(Ad ad);
}
