package com.facebook.ads.internal.api;

import androidx.annotation.Keep;
import com.facebook.ads.NativeAdLayout;

@Keep
public interface AdChoicesViewApi {
    void initialize(boolean z, NativeAdLayout nativeAdLayout);
}
