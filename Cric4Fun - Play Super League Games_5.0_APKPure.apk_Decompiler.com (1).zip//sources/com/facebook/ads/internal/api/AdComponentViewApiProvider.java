package com.facebook.ads.internal.api;

import androidx.annotation.Keep;

@Keep
public interface AdComponentViewApiProvider {
    AdComponentViewApi getAdComponentViewApi();
}
