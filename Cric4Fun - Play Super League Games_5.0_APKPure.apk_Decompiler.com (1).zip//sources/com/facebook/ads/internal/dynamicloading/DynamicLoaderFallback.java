package com.facebook.ads.internal.dynamicloading;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Keep;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.CacheFlag;
import com.facebook.ads.InstreamVideoAdListener;
import com.facebook.ads.InstreamVideoAdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.RewardedVideoAdListener;
import com.facebook.ads.internal.api.AdViewApi;
import com.facebook.ads.internal.api.AdViewParentApi;
import com.facebook.ads.internal.api.InstreamVideoAdViewApi;
import com.facebook.ads.internal.api.InterstitialAdApi;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.api.RewardedVideoAdApi;
import eu.dkaratzas.android.inapp.update.BuildConfig;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

@Keep
public class DynamicLoaderFallback {
    public static final WeakHashMap<Object, AdListener> sApiProxyToAdListenersMap = new WeakHashMap<>();

    public static class a implements InvocationHandler {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ List f1772a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ List f1773b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ Map f1774c;
        public final /* synthetic */ List d;
        public final /* synthetic */ Method e;
        public final /* synthetic */ Map f;
        public final /* synthetic */ List g;
        public final /* synthetic */ List h;
        public final /* synthetic */ List i;
        public final /* synthetic */ Method j;
        public final /* synthetic */ Method k;

        public a(List list, List list2, Map map, List list3, Method method, Map map2, List list4, List list5, List list6, Method method2, Method method3) {
            this.f1772a = list;
            this.f1773b = list2;
            this.f1774c = map;
            this.d = list3;
            this.e = method;
            this.f = map2;
            this.g = list4;
            this.h = list5;
            this.i = list6;
            this.j = method2;
            this.k = method3;
        }

        public Object invoke(Object obj, Method method, Object[] objArr) {
            Object obj2;
            if (method.getReturnType().isPrimitive()) {
                if (!method.getReturnType().equals(Void.TYPE)) {
                    return Array.get(Array.newInstance(method.getReturnType(), 1), 0);
                }
                Iterator it = this.f1772a.iterator();
                while (true) {
                    if (it.hasNext()) {
                        if (DynamicLoaderFallback.equalsMethods(method, (Method) it.next())) {
                            DynamicLoaderFallback.sApiProxyToAdListenersMap.put(obj, objArr[0]);
                            break;
                        }
                    } else {
                        break;
                    }
                }
                Iterator it2 = this.f1773b.iterator();
                while (it2.hasNext() && (!DynamicLoaderFallback.equalsMethods(method, (Method) it2.next()) || !DynamicLoaderFallback.reportError(obj, this.f1774c))) {
                }
                Iterator it3 = this.d.iterator();
                while (it3.hasNext() && (!DynamicLoaderFallback.equalsMethods(method, (Method) it3.next()) || !DynamicLoaderFallback.reportError(obj, this.f1774c))) {
                }
                if (!DynamicLoaderFallback.equalsMethods(method, this.e)) {
                    return null;
                }
                boolean unused = DynamicLoaderFallback.reportError(this.f.get(obj), this.f1774c);
                return null;
            } else if (method.getReturnType().equals(String.class)) {
                return BuildConfig.FLAVOR;
            } else {
                if (method.getReturnType().equals(obj.getClass().getInterfaces()[0])) {
                    obj2 = obj;
                } else {
                    obj2 = Proxy.newProxyInstance(DynamicLoaderFallback.class.getClassLoader(), new Class[]{method.getReturnType()}, this);
                }
                Iterator it4 = this.g.iterator();
                while (true) {
                    if (it4.hasNext()) {
                        if (DynamicLoaderFallback.equalsMethods(method, (Method) it4.next())) {
                            DynamicLoaderFallback.sApiProxyToAdListenersMap.put(this.f.get(obj), objArr[0]);
                            break;
                        }
                    } else {
                        break;
                    }
                }
                for (Method access$100 : this.h) {
                    if (DynamicLoaderFallback.equalsMethods(method, access$100)) {
                        this.f.put(obj2, obj);
                    }
                }
                for (Method access$1002 : this.i) {
                    if (DynamicLoaderFallback.equalsMethods(method, access$1002)) {
                        for (Ad ad : objArr) {
                            if (ad instanceof Ad) {
                                this.f1774c.put(obj2, ad);
                            }
                        }
                    }
                }
                if (DynamicLoaderFallback.equalsMethods(method, this.j)) {
                    this.f1774c.put(objArr[1], objArr[0]);
                }
                if (DynamicLoaderFallback.equalsMethods(method, this.k)) {
                    this.f1774c.put(objArr[1], objArr[0]);
                }
                return obj2;
            }
        }
    }

    public static class b implements Runnable {

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ AdListener f1775c;
        public final /* synthetic */ Ad d;

        public b(AdListener adListener, Ad ad) {
            this.f1775c = adListener;
            this.d = ad;
        }

        public void run() {
            this.f1775c.onError(this.d, new AdError(-1, DynamicLoaderFactory.DEX_LOADING_ERROR_MESSAGE));
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public Method f1776a;

        /* renamed from: b  reason: collision with root package name */
        public final InvocationHandler f1777b = new a();

        public class a implements InvocationHandler {
            public a() {
            }

            public Object invoke(Object obj, Method method, Object[] objArr) {
                if ("toString".equals(method.getName())) {
                    return null;
                }
                c.this.f1776a = method;
                return null;
            }
        }

        public /* synthetic */ c(a aVar) {
        }

        public <T> T a(Class<T> cls) {
            return cls.cast(Proxy.newProxyInstance(DynamicLoaderFallback.class.getClassLoader(), new Class[]{cls}, this.f1777b));
        }
    }

    public static boolean equalsMethodParams(Method method, Method method2) {
        return Arrays.equals(method.getParameterTypes(), method2.getParameterTypes());
    }

    public static boolean equalsMethods(Method method, Method method2) {
        return method != null && method2 != null && method.getDeclaringClass().equals(method2.getDeclaringClass()) && method.getName().equals(method2.getName()) && equalsMethodParams(method, method2);
    }

    @SuppressLint({"Parameter Not Nullable", "CatchGeneralException"})
    public static DynamicLoader makeFallbackLoader() {
        Class cls = DynamicLoader.class;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList();
        ArrayList arrayList6 = new ArrayList();
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        c cVar = new c((a) null);
        DynamicLoader dynamicLoader = (DynamicLoader) cVar.a(cls);
        dynamicLoader.createInterstitialAd((Context) null, (String) null, (InterstitialAd) null);
        arrayList6.add(cVar.f1776a);
        dynamicLoader.createRewardedVideoAd((Context) null, (String) null, (RewardedVideoAd) null);
        arrayList6.add(cVar.f1776a);
        dynamicLoader.createInstreamVideoAdViewApi((InstreamVideoAdView) null, (Context) null, (String) null, (AdSize) null);
        arrayList6.add(cVar.f1776a);
        dynamicLoader.createAdViewApi((Context) null, (String) null, (AdSize) null, (AdViewParentApi) null, (AdView) null);
        arrayList6.add(cVar.f1776a);
        try {
            dynamicLoader.createAdViewApi((Context) null, (String) null, (String) null, (AdViewParentApi) null, (AdView) null);
        } catch (Exception unused) {
        }
        arrayList6.add(cVar.f1776a);
        dynamicLoader.createNativeAdApi((NativeAd) null, (NativeAdBaseApi) null);
        Method method = cVar.f1776a;
        dynamicLoader.createNativeBannerAdApi((NativeBannerAd) null, (NativeAdBaseApi) null);
        Method method2 = cVar.f1776a;
        NativeAdBaseApi nativeAdBaseApi = (NativeAdBaseApi) cVar.a(NativeAdBaseApi.class);
        nativeAdBaseApi.loadAd();
        arrayList.add(cVar.f1776a);
        nativeAdBaseApi.loadAd((NativeAdBase.NativeLoadAdConfig) null);
        arrayList2.add(cVar.f1776a);
        nativeAdBaseApi.loadAd((NativeAdBase.MediaCacheFlag) null);
        arrayList.add(cVar.f1776a);
        nativeAdBaseApi.loadAdFromBid((String) null);
        arrayList.add(cVar.f1776a);
        nativeAdBaseApi.loadAdFromBid((String) null, (NativeAdBase.MediaCacheFlag) null);
        arrayList.add(cVar.f1776a);
        nativeAdBaseApi.buildLoadAdConfig((NativeAdBase) null);
        arrayList5.add(cVar.f1776a);
        nativeAdBaseApi.setAdListener((NativeAdListener) null, (NativeAdBase) null);
        arrayList3.add(cVar.f1776a);
        InterstitialAdApi interstitialAdApi = (InterstitialAdApi) cVar.a(InterstitialAdApi.class);
        interstitialAdApi.loadAd();
        arrayList.add(cVar.f1776a);
        interstitialAdApi.loadAd((EnumSet<CacheFlag>) null);
        arrayList.add(cVar.f1776a);
        interstitialAdApi.loadAd((InterstitialAd.InterstitialLoadAdConfig) null);
        arrayList2.add(cVar.f1776a);
        interstitialAdApi.loadAdFromBid((EnumSet<CacheFlag>) null, (String) null);
        arrayList.add(cVar.f1776a);
        interstitialAdApi.setAdListener((InterstitialAdListener) null);
        arrayList3.add(cVar.f1776a);
        interstitialAdApi.buildLoadAdConfig();
        arrayList5.add(cVar.f1776a);
        RewardedVideoAdApi rewardedVideoAdApi = (RewardedVideoAdApi) cVar.a(RewardedVideoAdApi.class);
        rewardedVideoAdApi.loadAd();
        arrayList.add(cVar.f1776a);
        rewardedVideoAdApi.loadAd((RewardedVideoAd.RewardedVideoLoadAdConfig) null);
        arrayList2.add(cVar.f1776a);
        rewardedVideoAdApi.loadAd(false);
        arrayList.add(cVar.f1776a);
        rewardedVideoAdApi.loadAdFromBid((String) null, false);
        arrayList.add(cVar.f1776a);
        rewardedVideoAdApi.setAdListener((RewardedVideoAdListener) null);
        arrayList3.add(cVar.f1776a);
        rewardedVideoAdApi.buildLoadAdConfig();
        arrayList5.add(cVar.f1776a);
        InstreamVideoAdViewApi instreamVideoAdViewApi = (InstreamVideoAdViewApi) cVar.a(InstreamVideoAdViewApi.class);
        instreamVideoAdViewApi.loadAd();
        arrayList.add(cVar.f1776a);
        instreamVideoAdViewApi.loadAd((InstreamVideoAdView.InstreamVideoLoadAdConfig) null);
        arrayList2.add(cVar.f1776a);
        instreamVideoAdViewApi.loadAdFromBid((String) null);
        arrayList.add(cVar.f1776a);
        instreamVideoAdViewApi.setAdListener((InstreamVideoAdListener) null);
        arrayList3.add(cVar.f1776a);
        instreamVideoAdViewApi.buildLoadAdConfig();
        arrayList5.add(cVar.f1776a);
        AdViewApi adViewApi = (AdViewApi) cVar.a(AdViewApi.class);
        adViewApi.loadAd();
        arrayList.add(cVar.f1776a);
        adViewApi.loadAd((AdView.AdViewLoadConfig) null);
        arrayList2.add(cVar.f1776a);
        adViewApi.loadAdFromBid((String) null);
        arrayList.add(cVar.f1776a);
        adViewApi.setAdListener((AdListener) null);
        arrayList3.add(cVar.f1776a);
        adViewApi.buildLoadAdConfig();
        arrayList5.add(cVar.f1776a);
        ((AdView.AdViewLoadConfigBuilder) cVar.a(AdView.AdViewLoadConfigBuilder.class)).withAdListener((AdListener) null);
        arrayList4.add(cVar.f1776a);
        NativeAdBase.NativeAdLoadConfigBuilder nativeAdLoadConfigBuilder = (NativeAdBase.NativeAdLoadConfigBuilder) cVar.a(NativeAdBase.NativeAdLoadConfigBuilder.class);
        nativeAdLoadConfigBuilder.withAdListener((NativeAdListener) null);
        arrayList4.add(cVar.f1776a);
        ((InterstitialAd.InterstitialAdLoadConfigBuilder) cVar.a(InterstitialAd.InterstitialAdLoadConfigBuilder.class)).withAdListener((InterstitialAdListener) null);
        arrayList4.add(cVar.f1776a);
        ((RewardedVideoAd.RewardedVideoAdLoadConfigBuilder) cVar.a(RewardedVideoAd.RewardedVideoAdLoadConfigBuilder.class)).withAdListener((RewardedVideoAdListener) null);
        arrayList4.add(cVar.f1776a);
        ((InstreamVideoAdView.InstreamVideoLoadConfigBuilder) cVar.a(InstreamVideoAdView.InstreamVideoLoadConfigBuilder.class)).withAdListener((InstreamVideoAdListener) null);
        arrayList4.add(cVar.f1776a);
        nativeAdLoadConfigBuilder.loadAd();
        a aVar = new a(arrayList3, arrayList, hashMap, arrayList2, cVar.f1776a, hashMap2, arrayList4, arrayList5, arrayList6, method, method2);
        return (DynamicLoader) Proxy.newProxyInstance(DynamicLoaderFallback.class.getClassLoader(), new Class[]{cls}, aVar);
    }

    public static boolean reportError(Object obj, Map<Object, Ad> map) {
        if (obj == null) {
            return false;
        }
        AdListener adListener = sApiProxyToAdListenersMap.get(obj);
        Ad ad = map.get(obj);
        if (adListener == null) {
            return false;
        }
        new Handler(Looper.getMainLooper()).postDelayed(new b(adListener, ad), 500);
        return true;
    }
}
