package com.live.pfl.ui;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import b.j.a.d;
import com.google.android.material.snackbar.Snackbar;
import com.live.pfl.R;

public class FantasyFragment extends d implements SwipeRefreshLayout.h {
    public WebView a0;
    public SwipeRefreshLayout b0;
    public String c0 = "https://www.cric4fun.com/";

    public class a extends WebViewClient {

        /* renamed from: com.live.pfl.ui.FantasyFragment$a$a  reason: collision with other inner class name */
        public class C0075a implements View.OnClickListener {
            public C0075a() {
            }

            public void onClick(View view) {
                FantasyFragment.this.v0();
            }
        }

        public a() {
        }

        public void onPageFinished(WebView webView, String str) {
            FantasyFragment.this.b0.setRefreshing(false);
            FantasyFragment.this.c0 = str;
            super.onPageFinished(webView, str);
        }

        public void onReceivedError(WebView webView, int i, String str, String str2) {
            Snackbar a2 = Snackbar.a(webView, "Connection Error", 0);
            a2.a("Retry", new C0075a());
            a2.h();
        }
    }

    public class b implements View.OnKeyListener {
        public b() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (i != 4 || keyEvent.getAction() != 1 || !FantasyFragment.this.a0.canGoBack()) {
                return false;
            }
            FantasyFragment.this.a0.goBack();
            return true;
        }
    }

    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_stadium, viewGroup, false);
        this.b0 = (SwipeRefreshLayout) inflate.findViewById(R.id.swipescreen);
        this.b0.setOnRefreshListener(this);
        return inflate;
    }

    public void c() {
        v0();
    }

    public void g0() {
        this.I = true;
        v0();
    }

    public void v0() {
        this.a0 = (WebView) f().findViewById(R.id.webview786);
        this.b0.setRefreshing(true);
        this.a0.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        this.a0.getSettings().setCacheMode(1);
        this.a0.getSettings().setAppCacheEnabled(true);
        WebSettings settings = this.a0.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        settings.setUseWideViewPort(true);
        settings.setSavePassword(true);
        settings.setSaveFormData(true);
        settings.setEnableSmoothTransition(true);
        this.a0.loadUrl(this.c0);
        this.a0.setWebViewClient(new a());
        this.a0.canGoBack();
        this.a0.setOnKeyListener(new b());
    }
}
