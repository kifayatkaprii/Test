package com.live.pfl.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import b.j.a.d;
import com.live.pfl.R;

public class FixtureFragment extends d {
    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_fixture, viewGroup, false);
    }
}
