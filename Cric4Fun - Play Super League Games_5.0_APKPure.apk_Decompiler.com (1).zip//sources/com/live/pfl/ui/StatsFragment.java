package com.live.pfl.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import b.j.a.d;
import c.b.b.i.b;
import c.b.b.i.c;
import c.b.b.i.e;
import c.b.b.i.f;
import c.b.b.i.g;
import c.b.b.i.j;
import c.b.b.i.n.o0;
import c.b.b.i.n.r0;
import c.b.b.i.n.v0.k;
import com.live.pfl.R;

public class StatsFragment extends d {
    public TextView A0;
    public TextView B0;
    public TextView C0;
    public TextView D0;
    public TextView E0;
    public TextView F0;
    public TextView G0;
    public TextView H0;
    public TextView I0;
    public TextView J0;
    public TextView K0;
    public TextView L0;
    public TextView M0;
    public int a0 = 1;
    public f b0;
    public e c0;
    public TextView d0;
    public TextView e0;
    public TextView f0;
    public TextView g0;
    public TextView h0;
    public TextView i0;
    public TextView j0;
    public TextView k0;
    public TextView l0;
    public TextView m0;
    public TextView n0;
    public TextView o0;
    public TextView p0;
    public TextView q0;
    public TextView r0;
    public TextView s0;
    public TextView t0;
    public TextView u0;
    public TextView v0;
    public TextView w0;
    public TextView x0;
    public TextView y0;
    public TextView z0;

    public class a implements j {
        public a() {
        }

        public void a(b bVar) {
            TextView textView;
            for (b bVar2 : new c.b.b.i.a(bVar, bVar.f1305a.iterator())) {
                String str = (String) bVar2.f1305a.f1642c.getValue();
                StatsFragment statsFragment = StatsFragment.this;
                int i = statsFragment.a0;
                if (i == 1) {
                    textView = statsFragment.H0;
                } else if (i == 2) {
                    textView = statsFragment.d0;
                } else if (i == 3) {
                    textView = statsFragment.e0;
                } else if (i == 4) {
                    textView = statsFragment.f0;
                } else if (i == 5) {
                    textView = statsFragment.g0;
                } else if (i == 6) {
                    textView = statsFragment.h0;
                } else if (i == 7) {
                    textView = statsFragment.I0;
                } else if (i == 8) {
                    textView = statsFragment.i0;
                } else if (i == 9) {
                    textView = statsFragment.j0;
                } else if (i == 10) {
                    textView = statsFragment.k0;
                } else if (i == 11) {
                    textView = statsFragment.l0;
                } else if (i == 12) {
                    textView = statsFragment.m0;
                } else if (i == 13) {
                    textView = statsFragment.J0;
                } else if (i == 14) {
                    textView = statsFragment.n0;
                } else if (i == 15) {
                    textView = statsFragment.o0;
                } else if (i == 16) {
                    textView = statsFragment.p0;
                } else if (i == 17) {
                    textView = statsFragment.q0;
                } else if (i == 18) {
                    textView = statsFragment.r0;
                } else if (i == 19) {
                    textView = statsFragment.K0;
                } else if (i == 20) {
                    textView = statsFragment.s0;
                } else if (i == 21) {
                    textView = statsFragment.t0;
                } else if (i == 22) {
                    textView = statsFragment.u0;
                } else if (i == 23) {
                    textView = statsFragment.v0;
                } else if (i == 24) {
                    textView = statsFragment.w0;
                } else if (i == 25) {
                    textView = statsFragment.L0;
                } else if (i == 26) {
                    textView = statsFragment.x0;
                } else if (i == 27) {
                    textView = statsFragment.y0;
                } else if (i == 28) {
                    textView = statsFragment.z0;
                } else if (i == 29) {
                    textView = statsFragment.A0;
                } else if (i == 30) {
                    textView = statsFragment.B0;
                } else if (i == 31) {
                    textView = statsFragment.M0;
                } else if (i == 32) {
                    textView = statsFragment.C0;
                } else if (i == 33) {
                    textView = statsFragment.D0;
                } else if (i == 34) {
                    textView = statsFragment.E0;
                } else if (i == 35) {
                    textView = statsFragment.F0;
                } else if (i == 36) {
                    textView = statsFragment.G0;
                }
                textView.setText(str);
                StatsFragment.this.a0++;
            }
        }

        public void a(c cVar) {
            Log.w("TAG", "Failed to read value.", cVar.a());
        }
    }

    public View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_stats, viewGroup, false);
        this.d0 = (TextView) inflate.findViewById(R.id.a1);
        this.e0 = (TextView) inflate.findViewById(R.id.a2);
        this.f0 = (TextView) inflate.findViewById(R.id.a3);
        this.g0 = (TextView) inflate.findViewById(R.id.a4);
        this.h0 = (TextView) inflate.findViewById(R.id.a5);
        this.i0 = (TextView) inflate.findViewById(R.id.b1);
        this.j0 = (TextView) inflate.findViewById(R.id.b2);
        this.k0 = (TextView) inflate.findViewById(R.id.b3);
        this.l0 = (TextView) inflate.findViewById(R.id.b4);
        this.m0 = (TextView) inflate.findViewById(R.id.b5);
        this.n0 = (TextView) inflate.findViewById(R.id.c1);
        this.o0 = (TextView) inflate.findViewById(R.id.c2);
        this.p0 = (TextView) inflate.findViewById(R.id.c3);
        this.q0 = (TextView) inflate.findViewById(R.id.c4);
        this.r0 = (TextView) inflate.findViewById(R.id.c5);
        this.s0 = (TextView) inflate.findViewById(R.id.d1);
        this.t0 = (TextView) inflate.findViewById(R.id.d2);
        this.u0 = (TextView) inflate.findViewById(R.id.d3);
        this.v0 = (TextView) inflate.findViewById(R.id.d4);
        this.w0 = (TextView) inflate.findViewById(R.id.d5);
        this.x0 = (TextView) inflate.findViewById(R.id.e1);
        this.y0 = (TextView) inflate.findViewById(R.id.e2);
        this.z0 = (TextView) inflate.findViewById(R.id.e3);
        this.A0 = (TextView) inflate.findViewById(R.id.e4);
        this.B0 = (TextView) inflate.findViewById(R.id.e5);
        this.C0 = (TextView) inflate.findViewById(R.id.f1);
        this.D0 = (TextView) inflate.findViewById(R.id.f2);
        this.E0 = (TextView) inflate.findViewById(R.id.f3);
        this.F0 = (TextView) inflate.findViewById(R.id.f4);
        this.G0 = (TextView) inflate.findViewById(R.id.f5);
        this.H0 = (TextView) inflate.findViewById(R.id.t_1);
        this.I0 = (TextView) inflate.findViewById(R.id.t_2);
        this.J0 = (TextView) inflate.findViewById(R.id.t_3);
        this.K0 = (TextView) inflate.findViewById(R.id.t_4);
        this.L0 = (TextView) inflate.findViewById(R.id.t_5);
        this.M0 = (TextView) inflate.findViewById(R.id.t_6);
        this.b0 = f.b();
        f fVar = this.b0;
        fVar.a();
        this.c0 = new e(fVar.f1312c, c.b.b.i.n.j.f);
        e a2 = this.c0.a("Standings");
        o0 o0Var = new o0(a2.f1314a, new a(), new k(a2.f1315b, a2.f1316c));
        r0.f1511b.a(o0Var);
        a2.f1314a.b((Runnable) new g(a2, o0Var));
        return inflate;
    }
}
