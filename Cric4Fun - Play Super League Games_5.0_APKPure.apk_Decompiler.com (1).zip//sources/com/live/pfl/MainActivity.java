package com.live.pfl;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import b.a.k.m;
import b.p.e;
import b.p.g;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import eu.dkaratzas.android.inapp.update.InAppUpdateManager;
import eu.dkaratzas.android.inapp.update.InAppUpdateStatus;

public class MainActivity extends m implements InAppUpdateManager.InAppUpdateHandler {
    public AdView q;
    public InterstitialAd r;
    public boolean s = false;
    public InAppUpdateManager t;

    public class a implements InterstitialAdListener {
        public a() {
        }

        public void onAdClicked(Ad ad) {
            MainActivity.p();
            Log.d("CodeGenix", "Interstitial ad clicked!");
        }

        public void onAdLoaded(Ad ad) {
            MainActivity.this.r.show();
        }

        public void onError(Ad ad, AdError adError) {
        }

        public void onInterstitialDismissed(Ad ad) {
            MainActivity.p();
            Log.e("CodeGenix", "Interstitial ad dismissed.");
        }

        public void onInterstitialDisplayed(Ad ad) {
            MainActivity.p();
            Log.e("CodeGenix", "Interstitial ad displayed.");
        }

        public void onLoggingImpression(Ad ad) {
            MainActivity.p();
            Log.d("CodeGenix", "Interstitial ad impression logged!");
        }
    }

    public class b implements e.c {
        public b() {
        }

        public void a(e eVar, g gVar, Bundle bundle) {
            if (gVar.e == R.id.navigation_dashboard) {
                MainActivity mainActivity = MainActivity.this;
                if (!mainActivity.s) {
                    mainActivity.r.loadAd();
                    MainActivity.this.s = true;
                } else {
                    mainActivity.o();
                }
            }
            if (gVar.e == R.id.navigation_notifications) {
                MainActivity mainActivity2 = MainActivity.this;
                if (!mainActivity2.s) {
                    mainActivity2.r.loadAd();
                    MainActivity.this.s = true;
                } else {
                    mainActivity2.o();
                }
            }
            if (gVar.e == R.id.navigation_stadiums) {
                MainActivity mainActivity3 = MainActivity.this;
                if (!mainActivity3.s) {
                    mainActivity3.r.loadAd();
                    MainActivity.this.s = true;
                } else {
                    mainActivity3.o();
                }
            }
            if (gVar.e == R.id.navigation_stats) {
                MainActivity mainActivity4 = MainActivity.this;
                if (!mainActivity4.s) {
                    mainActivity4.r.loadAd();
                    MainActivity.this.s = true;
                    return;
                }
                mainActivity4.o();
            }
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public void onClick(View view) {
            MainActivity.this.t.completeUpdate();
        }
    }

    public class d implements Runnable {
        public d() {
        }

        public void run() {
            InterstitialAd interstitialAd = MainActivity.this.r;
            if (interstitialAd != null && interstitialAd.isAdLoaded() && !MainActivity.this.r.isAdInvalidated()) {
                MainActivity.this.r.show();
            }
        }
    }

    public static /* synthetic */ String p() {
        return "CodeGenix";
    }

    public final void o() {
        new Handler().postDelayed(new d(), 300000);
    }

    public void onBackPressed() {
        b.j.a.d a2 = d().a(R.id.nav_host_fragment);
        if (!(a2 instanceof c.c.a.a.a) || !((c.c.a.a.a) a2).onBackPressed()) {
            super.onBackPressed();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x00bc  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00ba A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onCreate(android.os.Bundle r7) {
        /*
            r6 = this;
            super.onCreate(r7)
            r7 = 2131427356(0x7f0b001c, float:1.8476326E38)
            r6.setContentView((int) r7)
            b.a.k.a r7 = r6.k()
            r7.d()
            r7 = 123(0x7b, float:1.72E-43)
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = eu.dkaratzas.android.inapp.update.InAppUpdateManager.Builder(r6, r7)
            r0 = 1
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r7.resumeUpdates(r0)
            eu.dkaratzas.android.inapp.update.Constants$UpdateMode r0 = eu.dkaratzas.android.inapp.update.Constants.UpdateMode.FLEXIBLE
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r7.mode(r0)
            java.lang.String r0 = "An update has just been downloaded."
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r7.snackBarMessage(r0)
            java.lang.String r0 = "RESTART"
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r7.snackBarAction(r0)
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r7.handler(r6)
            r6.t = r7
            eu.dkaratzas.android.inapp.update.InAppUpdateManager r7 = r6.t
            r7.checkForAppUpdate()
            com.facebook.ads.AudienceNetworkAds.initialize(r6)
            com.facebook.ads.AdView r7 = new com.facebook.ads.AdView
            com.facebook.ads.AdSize r0 = com.facebook.ads.AdSize.BANNER_HEIGHT_50
            java.lang.String r1 = "296183304381049_296185507714162"
            r7.<init>((android.content.Context) r6, (java.lang.String) r1, (com.facebook.ads.AdSize) r0)
            r6.q = r7
            r7 = 2131230764(0x7f08002c, float:1.807759E38)
            android.view.View r7 = r6.findViewById(r7)
            android.widget.LinearLayout r7 = (android.widget.LinearLayout) r7
            com.facebook.ads.AdView r0 = r6.q
            r7.addView(r0)
            com.facebook.ads.AdView r7 = r6.q
            r7.loadAd()
            com.facebook.ads.InterstitialAd r7 = new com.facebook.ads.InterstitialAd
            java.lang.String r0 = "296183304381049_296556111010435"
            r7.<init>(r6, r0)
            r6.r = r7
            com.facebook.ads.InterstitialAd r7 = r6.r
            com.live.pfl.MainActivity$a r0 = new com.live.pfl.MainActivity$a
            r0.<init>()
            r7.setAdListener(r0)
            r7 = 2131230865(0x7f080091, float:1.8077795E38)
            android.view.View r7 = r6.findViewById(r7)
            com.google.android.material.bottomnavigation.BottomNavigationView r7 = (com.google.android.material.bottomnavigation.BottomNavigationView) r7
            r0 = 5
            int[] r0 = new int[r0]
            r0 = {2131230868, 2131230866, 2131230869, 2131230871, 2131230870} // fill-array
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            int r2 = r0.length
            r3 = 0
        L_0x0082:
            if (r3 >= r2) goto L_0x0090
            r4 = r0[r3]
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r1.add(r4)
            int r3 = r3 + 1
            goto L_0x0082
        L_0x0090:
            b.p.t.c r0 = new b.p.t.c
            r2 = 0
            r0.<init>(r1, r2, r2, r2)
            r1 = 2131230864(0x7f080090, float:1.8077793E38)
            android.view.View r3 = b.f.d.a.a(r6, r1)
        L_0x009d:
            if (r3 == 0) goto L_0x00c9
            int r4 = b.p.p.nav_controller_view_tag
            java.lang.Object r4 = r3.getTag(r4)
            boolean r5 = r4 instanceof java.lang.ref.WeakReference
            if (r5 == 0) goto L_0x00b0
            java.lang.ref.WeakReference r4 = (java.lang.ref.WeakReference) r4
            java.lang.Object r4 = r4.get()
            goto L_0x00b4
        L_0x00b0:
            boolean r5 = r4 instanceof b.p.e
            if (r5 == 0) goto L_0x00b7
        L_0x00b4:
            b.p.e r4 = (b.p.e) r4
            goto L_0x00b8
        L_0x00b7:
            r4 = r2
        L_0x00b8:
            if (r4 == 0) goto L_0x00bc
            r2 = r4
            goto L_0x00c9
        L_0x00bc:
            android.view.ViewParent r3 = r3.getParent()
            boolean r4 = r3 instanceof android.view.View
            if (r4 == 0) goto L_0x00c7
            android.view.View r3 = (android.view.View) r3
            goto L_0x009d
        L_0x00c7:
            r3 = r2
            goto L_0x009d
        L_0x00c9:
            if (r2 == 0) goto L_0x00f1
            b.p.t.b r1 = new b.p.t.b
            r1.<init>(r6, r0)
            r2.a((b.p.e.c) r1)
            b.p.t.d r0 = new b.p.t.d
            r0.<init>(r2)
            r7.setOnNavigationItemSelectedListener(r0)
            java.lang.ref.WeakReference r0 = new java.lang.ref.WeakReference
            r0.<init>(r7)
            b.p.t.e r7 = new b.p.t.e
            r7.<init>(r0, r2)
            r2.a((b.p.e.c) r7)
            com.live.pfl.MainActivity$b r7 = new com.live.pfl.MainActivity$b
            r7.<init>()
            r2.a((b.p.e.c) r7)
            return
        L_0x00f1:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r2 = "Activity "
            r0.append(r2)
            r0.append(r6)
            java.lang.String r2 = " does not have a NavController set on "
            r0.append(r2)
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r7.<init>(r0)
            goto L_0x0111
        L_0x0110:
            throw r7
        L_0x0111:
            goto L_0x0110
        */
        throw new UnsupportedOperationException("Method not decompiled: com.live.pfl.MainActivity.onCreate(android.os.Bundle):void");
    }

    public void onDestroy() {
        AdView adView = this.q;
        if (adView != null) {
            adView.destroy();
        }
        InterstitialAd interstitialAd = this.r;
        if (interstitialAd != null) {
            interstitialAd.destroy();
        }
        super.onDestroy();
    }

    public void onInAppUpdateError(int i, Throwable th) {
    }

    public void onInAppUpdateStatus(InAppUpdateStatus inAppUpdateStatus) {
        if (inAppUpdateStatus.isDownloaded()) {
            Snackbar a2 = Snackbar.a(getWindow().getDecorView().findViewById(16908290), "An update has just been downloaded.", 0);
            a2.a("RESTART", new c());
            a2.h();
        }
    }
}
